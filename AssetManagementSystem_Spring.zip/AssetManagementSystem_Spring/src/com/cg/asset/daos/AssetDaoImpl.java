package com.cg.asset.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.asset.dtos.*;
import com.cg.asset.exception.*;

@Repository("assetDao")
public class AssetDaoImpl implements IAssetDao {
	
	@PersistenceContext
	private EntityManager manager;
	
	
	@Override
	public List<Asset> getAssetDetailsListAdmin() throws AssetException {
		Query query = manager.createNamedQuery("qryAllAssets",Asset.class);
		return query.getResultList();
	}

	
	@Override
	public User getUserDetails(String userName) throws AssetException {

		System.out.println(userName);
		Query query = manager.createNamedQuery ("qryUserOnUsername",User.class);
		query.setParameter("uname",userName);
		return (User) query.getSingleResult();
	}

	@Override
	public List<Employee> getAvailableEmployees(int mgrId) throws AssetException {
		
		Query query = manager.createNamedQuery("qryAvailableEmployees",Employee.class);
		query.setParameter("mgrId",mgrId);
		return  query.getResultList();
		
	}


	@Override
	public List<Asset> getAvailableAssetsDetails() throws AssetException {
		System.out.println("yy");
		Query query = manager.createNamedQuery("qryAvailableAssetsDetails",Asset.class);
		List<Asset> availAssetDetails= query.getResultList();
		return availAssetDetails;
	}


	/*@Override
	public int getEmpNo(String empName) throws AssetException {
		Query query = manager.createNamedQuery("qryEnoFromEname",Asset.class);
		query.setParameter("empName",empName);	
		return (int) query.getSingleResult();

	}

	@Override
	public int getAssetId(String assetName) throws AssetException {
		Query query = manager.createNamedQuery("qryAssetIdFromAssetName",Asset.class);
		query.setParameter("assetName",assetName);	
		return (int) query.getSingleResult();
	}*/
	
	

	@Override
	public int addRequest(Request req) throws AssetException {
		req.setEmp(manager.find(Employee.class, req.getEmp().getEmpno()));
		req.setAsset(manager.find(Asset.class, req.getAsset().getAssetId()));	
		manager.persist(req);
		return 0;
	}


	@Override
	public List<Request> showAllRequests(int mgrId) {
		Query qry=manager.createNamedQuery("qryListAvailRequests",Request.class);	
		qry.setParameter("mgrId", mgrId);		
		return qry.getResultList();
	}



}
