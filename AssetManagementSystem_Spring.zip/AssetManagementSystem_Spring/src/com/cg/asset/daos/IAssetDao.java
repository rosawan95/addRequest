package com.cg.asset.daos;

import java.util.List;

import com.cg.asset.dtos.*;
import com.cg.asset.exception.*;

public interface IAssetDao {

	public List<Asset> getAssetDetailsListAdmin() throws AssetException;

	public User getUserDetails(String userName) throws AssetException;

	//To create data which is to be displayed on the asset request form
	List<Employee> getAvailableEmployees(int mgrId) throws AssetException;
	List<Asset> getAvailableAssetsDetails() throws AssetException;
	
	//Add asset request data. 
	/*int getEmpNo(String empName) throws AssetException;
	int getAssetId(String assetName) throws AssetException;*/

	//add request
	int addRequest(Request req) throws AssetException;
	
	//show request data
	public List<Request> showAllRequests(int mgrId);
	
}
