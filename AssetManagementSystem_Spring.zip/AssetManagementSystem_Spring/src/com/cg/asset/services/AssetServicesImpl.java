package com.cg.asset.services;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.asset.daos.AssetDaoImpl;
import com.cg.asset.dtos.Asset;
import com.cg.asset.dtos.Employee;
import com.cg.asset.dtos.Request;
import com.cg.asset.dtos.User;
import com.cg.asset.exception.AssetException;

@Service("assetService")
@Transactional
public class AssetServicesImpl implements IAssetServices {

	
	AssetDaoImpl dao;

	
	@Resource(name="assetDao")
	public void setAssetDao(AssetDaoImpl dao){
		this.dao = dao;
	}


	@Override
	public List<Asset> getAssetDetailsListAdmin() throws AssetException {
		return dao.getAssetDetailsListAdmin();
	}


	@Override
	public List<Integer> authenticate(String userName, String password)
			throws AssetException {
		
		List<Integer> myList = new ArrayList<Integer>();
		
		User user = dao.getUserDetails(userName);
		String privilege = "Admin";

		System.out.println(user);

		if (password.equals(user.getUserPassword())) {
			if (privilege.equals(user.getUserType())) {
				
				myList.add(1);
				myList.add(0);
			}
			myList.add(2);
			int empId=user.getEmpid().getEmpno();
			System.out.println("employee id of manager logged in "+empId);
			myList.add(empId);
			
		}
		else{
			myList.add(0);
		}
		return myList;
	}

	@Override
	public List<Employee> getAvailableEmployees(int mgrId)
			throws AssetException {
		return dao.getAvailableEmployees(mgrId);
	}

	@Override
	public List<Asset> getAvailableAssetsDetails() throws AssetException {
		// TODO Auto-generated method stub
		return dao.getAvailableAssetsDetails();
	}

/*
	@Override
	public int getEmpNo(String empName) throws AssetException {
		// TODO Auto-generated method stub
		return dao.getEmpNo(empName);
	}

	@Override
	public int getAssetId(String assetName) throws AssetException {
		// TODO Auto-generated method stub
		return dao.getAssetId(assetName);
	}
*/

	@Override
	public int addRequest(Request req) throws AssetException {
		return dao.addRequest(req); 
	}


	@Override
	public List<Request> showAllRequests(int mgrId) {
		// TODO Auto-generated method stub
		return dao.showAllRequests(mgrId);
		
	}


	/*@Override
	public int getEmployeeNoFromUserName(String userName) throws AssetException {
		User user = dao.getUserDetails(userName);
		return user.getEmp().getEmpno();
		
	}*/
	
}